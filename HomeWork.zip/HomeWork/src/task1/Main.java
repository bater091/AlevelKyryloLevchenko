package task1;

public class Main {
    public static void main(String[] args){
        String Name = "Kyrylo";
        String Surname = "Levchenko";
        System.out.println(Name + " " + Surname);

        if(Name.length()>7){
            System.out.println("more than 7");
        }
        else{
            System.out.println("less than 7");

        }
        int result = 5;
        for(int i = 0; i <=10; i++ ){
            System.out.println("Step " + i + ", result " + result);
            result += 2;

        }


    }
}